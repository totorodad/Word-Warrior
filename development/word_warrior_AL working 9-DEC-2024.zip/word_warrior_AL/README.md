Word warrior is a tile game for spelling words on a game board.  This game use my gameserver.py on a hosted network (can be your home network) with port 5000 forwared.  The wordwarrior_client.py connects up to four players.  You play your word hit go and if needed press
the dictionary button and the Collins dictionary will be used to check the words you've played on the board. 

Boulder Creek Video Games (BCVG)
Freeware released under the GPL 3.0
BCVG claims no copyright or tradmark on this game.
This game for education purposes only.
Contact totorodad@gmail.com
30-Nov-2024